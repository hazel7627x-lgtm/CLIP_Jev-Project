"""Save frozen raw CLIP cosine scores; never read gold labels or fit a classifier."""
import argparse
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import time


def fingerprint(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_jsonl(path):
    rows = [json.loads(s) for s in Path(path).read_text(encoding='utf-8-sig').splitlines() if s.strip()]
    if len({r['id'] for r in rows}) != len(rows):
        raise ValueError(f'Duplicate IDs: {path}')
    return rows


def atomic_write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', encoding='utf-8', newline='\n') as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary, path)


def save_json(path, value):
    atomic_write(path, json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def validate_cached(cached, inputs, signature):
    expected = {r['id']:r for r in inputs}
    if len({r['id'] for r in cached}) != len(cached):
        raise ValueError('Duplicate cached predictions')
    for r in cached:
        if r['id'] not in expected:
            raise ValueError('Unexpected prediction ID')
        source = expected[r['id']]
        if r['image_id'] != source['image_id'] or r['input_manifest_sha256'] != signature['manifest_sha256']:
            raise ValueError('Cached image or manifest mismatch')
        if r['backbone_revision'] != signature['backbone']['revision']:
            raise ValueError('Cached backbone mismatch')
        if r['claim_sha256'] != hashlib.sha256(source['claim'].encode('utf-8')).hexdigest():
            raise ValueError('Cached claim mismatch')
        score = r['cosine']
        if not math.isfinite(score) or not -1.00001 <= score <= 1.00001:
            raise ValueError('Invalid cosine')
        if not math.isfinite(r['conflict_score']) or abs(r['conflict_score'] - (1-score)) > 1e-8:
            raise ValueError('conflict_score must equal 1-cosine')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--splits', nargs='+', choices=['validation','test'], default=['validation','test'])
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--device', choices=['auto','cpu','cuda'], default='auto')
    parser.add_argument('--resume', action='store_true')
    a = parser.parse_args()
    if a.batch_size < 1: parser.error('batch-size must be positive')
    root = a.root.resolve()
    lock = json.loads((root/'backbone_lock.json').read_text(encoding='utf-8'))
    config = json.loads((root/'experiment_config.json').read_text(encoding='utf-8'))
    assert lock == {k:config['backbone'][k] for k in ['model_id','revision']}, 'Backbone configuration differs'
    image_hashes = json.loads((root/'image_sha256.json').read_text(encoding='utf-8'))

    import torch
    from PIL import Image
    from transformers import CLIPModel, CLIPProcessor
    device = ('cuda' if torch.cuda.is_available() else 'cpu') if a.device=='auto' else a.device
    if device=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; use --device cpu or enable a GPU later')
    torch.manual_seed(42)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    versions = {p:importlib.metadata.version(p) for p in ['torch','transformers','Pillow']}
    model = processor = None
    verified_images = set()
    for split in dict.fromkeys(a.splits):
        manifest = root/'manifests'/f'{split}_inputs.jsonl'
        rows = read_jsonl(manifest)
        if not rows: raise ValueError('Empty input manifest')
        out = root/'runs'/'clip_raw'/f'{split}_raw_clip.jsonl'
        meta_path = Path(str(out)+'.meta.json')
        signature = dict(schema_version='clip-raw-v1', backbone=lock,
                         manifest_sha256=fingerprint(manifest), image_hashes_sha256=fingerprint(root/'image_sha256.json'),
                         runner_sha256=fingerprint(__file__), dtype='float32', device=device,
                         device_name=torch.cuda.get_device_name() if device=='cuda' else 'cpu',
                         batch_size=a.batch_size, versions=versions,
                         preprocessing='pinned CLIPProcessor defaults; RGB; no augmentation; no text truncation')
        cached = []
        if out.exists() or meta_path.exists():
            if not a.resume: raise FileExistsError(f'{out}: use --resume or a new output folder')
            if not meta_path.exists(): raise ValueError('Existing predictions have no provenance metadata')
            old = json.loads(meta_path.read_text(encoding='utf-8'))
            if old['signature'] != signature:
                raise ValueError('Resume signature changed (model, inputs, code, environment or batch); use a separate run folder')
            cached = read_jsonl(out) if out.exists() else []
            validate_cached(cached, rows, signature)
        # Verify every selected image even when reusing completed scores.
        image_paths = {}
        for r in rows:
            if not isinstance(r['claim'],str) or not r['claim'].strip(): raise ValueError('Empty claim')
            path = (root/r['image']).resolve()
            if not path.is_relative_to(root): raise ValueError('Image path escapes dataset directory')
            if r['image_id'] in image_paths and image_paths[r['image_id']] != path:
                raise ValueError('Image ID refers to multiple files')
            image_paths[r['image_id']] = path
            if path not in verified_images:
                if fingerprint(path) != image_hashes[r['image_id']]: raise ValueError(f'Image hash mismatch: {path.name}')
                verified_images.add(path)
        done = {r['id']:r for r in cached}
        pending = [r for r in rows if r['id'] not in done]
        meta = dict(signature=signature, split=split, expected=len(rows), completed=len(done), complete=False,
                    gold_labels_read=False, fitted_parameters=False, score='cosine of L2-normalized projected embeddings; NOT scaled CLIP logits or probabilities')
        save_json(meta_path, meta)
        if pending and model is None:
            print(f'Loading {lock["model_id"]}@{lock["revision"]} on {device} (float32)', flush=True)
            processor = CLIPProcessor.from_pretrained(lock['model_id'], revision=lock['revision'])
            model = CLIPModel.from_pretrained(lock['model_id'], revision=lock['revision']).to(device=device,dtype=torch.float32).eval()
            model.requires_grad_(False)
        for start in range(0,len(pending),a.batch_size):
            batch_rows = pending[start:start+a.batch_size]
            claims = [r['claim'] for r in batch_rows]
            lengths = processor.tokenizer(claims,truncation=False,padding=False)['input_ids']
            if any(len(t)>model.config.text_config.max_position_embeddings for t in lengths):
                raise ValueError('CLIP 77-token limit exceeded; refusing silent truncation')
            images=[]
            try:
                for r in batch_rows:
                    with Image.open(image_paths[r['image_id']]) as im: images.append(im.convert('RGB'))
                encoded=processor(text=claims,images=images,padding=True,truncation=False,return_tensors='pt').to(device)
                with torch.inference_mode():
                    result=model(**encoded)
                    # Each row is a matched image/claim pair; do not use the whole pairwise score matrix.
                    v=torch.nn.functional.normalize(result.image_embeds.float(),dim=-1)
                    t=torch.nn.functional.normalize(result.text_embeds.float(),dim=-1)
                    scores=(v*t).sum(-1).cpu().tolist()
            finally:
                for im in images: im.close()
            for r,s in zip(batch_rows,scores):
                if not math.isfinite(s) or not -1.00001<=s<=1.00001: raise ValueError('Invalid model score')
                done[r['id']]=dict(schema_version='clip-raw-v1',id=r['id'],image_id=r['image_id'],split=split,
                    cosine=s,conflict_score=1-s,backbone_model=lock['model_id'],backbone_revision=lock['revision'],
                    input_manifest_sha256=signature['manifest_sha256'],image_sha256=image_hashes[r['image_id']],
                    claim_sha256=hashlib.sha256(r['claim'].encode('utf-8')).hexdigest())
            # Atomic snapshot after each batch avoids a half-written JSONL line on interruption.
            atomic_write(out,''.join(json.dumps(done[r['id']],ensure_ascii=False,allow_nan=False)+'\n' for r in rows if r['id'] in done))
            meta['completed']=len(done)
            save_json(meta_path,meta)
            print(f'{split}: {len(done)}/{len(rows)} saved',flush=True)
        validate_cached(list(done.values()),rows,signature)
        assert set(done)=={r['id'] for r in rows}
        meta.update(complete=True,completed=len(done),predictions_sha256=fingerprint(out))
        save_json(meta_path,meta)
        print(f'COMPLETE: {out} ({len(done)} pairs); no gold labels or metrics used',flush=True)


if __name__=='__main__': main()
